# Lisez-moi - site web statique fonio

Ce récit a été exporté depuis le logiciel libre Fonio.

Veuillez noter que le site que vous avez téléchargé ne fonctionnera pas en ouvrant les fichiers HTML directement sur votre ordinateur : il vous faut lancer un serveur local ou le mettre en ligne pour le voir fonctionner.

Vous pouvez vous référer à ce tutoriel pour mettre en place un serveur local : http://craym.eu/tutoriels/developpement/site_local_avec_wamp.html

Vous pouvez vous référer à ce tutoriel pour publier votre récit en ligne : https://developer.mozilla.org/fr/docs/Apprendre/Commencer_avec_le_web/Publier_votre_site_web#Publier_via_GitHub

Voici quelques suggestions de solutions pour mettre le site en ligne gratuitement :

**Github Pages** - https://github.com - tutoriel ici : https://developer.mozilla.org/fr/docs/Apprendre/Commencer_avec_le_web/Publier_votre_site_web#Publier_via_GitHub

**Netlify drop** - https://app.netlify.com/drop